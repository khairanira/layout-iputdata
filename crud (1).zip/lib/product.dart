import 'package:flutter/material.dart';

class Product extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(title: 'Flutter Tutorial', debugShowCheckedModeBanner: false, home: Main());
  }
}

class Main extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Products', style: TextStyle(color: Colors.blueAccent, fontSize: 27, letterSpacing: 1)),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 5,
        leading: Icon(Icons.arrow_back, color: Colors.blueAccent, size: 27),
      ),
      body: Text(
        "Product Information",
        textAlign: TextAlign.end,
        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
      ),
    );
  }
}
