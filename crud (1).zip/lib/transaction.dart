import 'package:flutter/material.dart';

class Transaction extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(title: 'Flutter Tutorials', debugShowCheckedModeBanner: false, home: Main());
  }
}

class Main extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Add Products', style: TextStyle(color: Colors.white, fontSize: 27, letterSpacing: 1)),
          centerTitle: true,
          backgroundColor: Colors.pink.shade800,
          elevation: 5,
          leading: Icon(Icons.arrow_back, color: Colors.white, size: 27),
        ),
        body: Stack(children: <Widget>[
          Container(
            height: double.infinity,
            width: double.infinity,
          ),
          Container(
            height: double.infinity,
            child: SingleChildScrollView(
              physics: AlwaysScrollableScrollPhysics(),
              padding: EdgeInsets.symmetric(
                horizontal: 10.0,
                vertical: 5.0,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Text(
                    'Product Information',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    'Product Image',
                    style: TextStyle(
                      fontSize: 15,
                      color: Colors.grey,
                    ),
                  ),
                  Container(
                      margin: EdgeInsets.all(10.0),
                      height: 150,
                      child: Center(
                        child: Icon(Icons.add, size: 50, color: Colors.pink.shade800),
                      ),
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: Colors.pink.shade50,
                        border: Border.all(
                          color: Colors.pink.shade800,
                          width: 2,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      )),
                  SizedBox(height: 20.0),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'Product Name',
                      ),
                      SizedBox(height: 10.0),
                      Container(
                        alignment: Alignment.centerLeft,
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Colors.pink.shade900,
                            width: 2,
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        height: 60.0,
                        child: TextField(
                            keyboardType: TextInputType.emailAddress,
                            style: TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              contentPadding: EdgeInsets.only(left: 10.0),
                              border: InputBorder.none,
                              hintText: 'Bag Sip',
                              hintStyle: TextStyle(fontSize: 15.0, color: Colors.grey),
                            )),
                      ),
                    ],
                  ),
                  SizedBox(height: 20.0),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'Product ID',
                      ),
                      SizedBox(height: 10.0),
                      Container(
                        alignment: Alignment.centerLeft,
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Colors.pink.shade900,
                            width: 2,
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        height: 60.0,
                        child: TextField(
                            keyboardType: TextInputType.emailAddress,
                            style: TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              contentPadding: EdgeInsets.only(left: 10.0),
                              border: InputBorder.none,
                              hintText: 'BAG-104',
                              hintStyle: TextStyle(fontSize: 15.0, color: Colors.grey),
                            )),
                      ),
                    ],
                  ),
                  SizedBox(height: 20.0),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'Price',
                      ),
                      SizedBox(height: 10.0),
                      Container(
                        alignment: Alignment.centerLeft,
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Colors.pink.shade900,
                            width: 2,
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        height: 60.0,
                        child: TextField(
                            keyboardType: TextInputType.emailAddress,
                            style: TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              contentPadding: EdgeInsets.only(left: 10.0),
                              border: InputBorder.none,
                              hintText: 'Rp. 1.000.000',
                              hintStyle: TextStyle(fontSize: 15.0, color: Colors.grey),
                            )),
                      ),
                    ],
                  ),
                  SizedBox(height: 20.0),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'Stock',
                      ),
                      SizedBox(height: 10.0),
                      Container(
                        alignment: Alignment.centerLeft,
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Colors.pink.shade900,
                            width: 2,
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        height: 60.0,
                        child: TextField(
                            keyboardType: TextInputType.emailAddress,
                            style: TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              contentPadding: EdgeInsets.only(left: 10.0),
                              border: InputBorder.none,
                              hintText: 'BAG-104 ready',
                              hintStyle: TextStyle(fontSize: 15.0, color: Colors.grey),
                            )),
                      ),
                    ],
                  ),
                  SizedBox(height: 20.0),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'Description',
                      ),
                      SizedBox(height: 10.0),
                      Container(
                        alignment: Alignment.centerLeft,
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Colors.pink.shade900,
                            width: 2,
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        height: 100.0,
                        child: TextField(
                            keyboardType: TextInputType.emailAddress,
                            style: TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              contentPadding: EdgeInsets.only(left: 10.0),
                              border: InputBorder.none,
                              hintText: 'Enter a Description',
                              hintStyle: TextStyle(fontSize: 15.0, color: Colors.grey),
                            )),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          )
        ]));
  }
}
